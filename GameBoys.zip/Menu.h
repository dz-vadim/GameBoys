#ifndef MENU_H
#define MENU_H

void menu();
int modeSelect();

#endif
