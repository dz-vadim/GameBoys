#ifndef RACEGAME_H
#define RACEGAME_H

void initRaceGame();
void raceGameLoop();

#endif
