#ifndef SNAKEGAME_H
#define SNAKEGAME_H

void initSnakeGame();
void snakeGameLoop();

#endif
